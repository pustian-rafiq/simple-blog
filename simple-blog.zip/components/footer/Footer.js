import React from 'react'

const Footer = () => {
  return (
    <div className="bg-success py-3 text-center">Footer</div>
  )
}

export default Footer