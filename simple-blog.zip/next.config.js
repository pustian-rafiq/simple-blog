/** @type {import('next').NextConfig} */
// const nextConfig = {
//   reactStrictMode: true,
// }

// module.exports = nextConfig
module.exports = {
  images: {
    // reactStrictMode: true,
    domains: ['via.placeholder.com'],
  },
};
