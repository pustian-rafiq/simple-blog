"use strict";
exports.id = 774;
exports.ids = [774];
exports.modules = {

/***/ 1494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function Meta({ title , description , keywords  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                charSet: "utf-8"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                httpEquiv: "X-UA-Compatible",
                content: "IE=edge"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: keywords
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "og:title",
                content: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "og:description",
                content: description
            })
        ]
    });
}
Meta.defaultProps = {
    title: "Simple - Blog",
    description: "It is a blog site",
    keywords: "php,react,vue"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);


/***/ }),

/***/ 7795:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fR": () => (/* binding */ deletePost),
/* harmony export */   "xQ": () => (/* binding */ getPostLists),
/* harmony export */   "zb": () => (/* binding */ getPostDetails)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2509);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, react_toastify__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getPosts = (posts)=>({
        type: _types__WEBPACK_IMPORTED_MODULE_2__/* .FETCH_POST_DATA */ .cX,
        payload: posts
    });
const getPost = (post)=>({
        type: _types__WEBPACK_IMPORTED_MODULE_2__/* .FETCH_POST_DETAILS */ .Dm,
        payload: post
    });
// Fetch all post's list
const getPostLists = ()=>{
    return function(dispatch) {
        axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://jsonplaceholder.typicode.com/posts").then((resp)=>{
            const posts = resp.data.slice(0, 20);
            const postWithComments = posts.map((post)=>axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://jsonplaceholder.typicode.com/posts/${post.id}/comments`).then((response)=>({
                        ...post,
                        comments: response.data
                    })));
            return Promise.all(postWithComments);
        }).then((postWithComments)=>{
            const postWithCommentUser = postWithComments.slice(0, 20);
            const postCommentUser = postWithCommentUser.map((postComment)=>axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://jsonplaceholder.typicode.com/users").then((response)=>({
                        ...postComment,
                        user: response.data.find((user)=>user.id === postComment.userId)
                    })));
            return Promise.all(postCommentUser);
        }).then((postCommentUser)=>{
            const postWithCommentUsers = postCommentUser.slice(0, 20);
            const postCommentUserPhoto = postWithCommentUsers.map((postCommentUser)=>axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://jsonplaceholder.typicode.com/photos").then((response)=>({
                        ...postCommentUser,
                        photo: response.data.find((user)=>user.id === postCommentUser.userId).url
                    })));
            return Promise.all(postCommentUserPhoto);
        }).then((postCommentUserPhoto)=>{
            console.log("postCommentUserPhoto", postCommentUserPhoto);
            dispatch(getPosts(postCommentUserPhoto));
        }).catch((error)=>{
            console.log(error);
        });
    };
};
// Fetch post details
const getPostDetails = (id)=>{
    return function(dispatch) {
        axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://jsonplaceholder.typicode.com/posts/${id}`).then((resp)=>{
            console.log(resp.data);
            const post = resp.data;
            var postWithComments = axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://jsonplaceholder.typicode.com/posts/${id}/comments`).then((response)=>({
                    ...post,
                    comments: response.data
                }));
            // console.log("postWithComments",postWithComments);
            return Promise.resolve(postWithComments);
        }).then((postWithComments)=>{
            console.log("postWithComments", postWithComments);
            const postComment = postWithComments;
            let postCommentUser = axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://jsonplaceholder.typicode.com/users").then((response)=>({
                    ...postComment,
                    user: response.data.find((user)=>user.id === postWithComments.userId)
                }));
            console.log("postCommentUser Details", postCommentUser.object);
            return Promise.resolve(postCommentUser);
        }).then((postCommentUser)=>{
            const postWithCommentUsers = postCommentUser;
            const postCommentUserPhoto = axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://jsonplaceholder.typicode.com/photos").then((response)=>({
                    ...postCommentUser,
                    photo: response.data.find((user)=>user.id === postWithCommentUsers.userId).url
                }));
            return Promise.resolve(postCommentUserPhoto);
        }).then((postCommentUserPhoto)=>{
            console.log("postCommentUserPhoto Details", postCommentUserPhoto);
            dispatch(getPost(postCommentUserPhoto));
        }).catch((error)=>{
        //console.log(error)
        });
    };
};
// Delete Post
const deletePost = (id)=>{
    return function(dispatch) {
        axios__WEBPACK_IMPORTED_MODULE_0__["default"]["delete"](`https://jsonplaceholder.typicode.com/posts/${id}`).then((resp)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success("Post deleted successfully");
            dispatch({
                type: _types__WEBPACK_IMPORTED_MODULE_2__/* .DELETE_POST */ .Xv,
                payload: id
            });
        // dispatch(getPostLists())
        }).catch((error)=>console.log(error));
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dm": () => (/* binding */ FETCH_POST_DETAILS),
/* harmony export */   "Xv": () => (/* binding */ DELETE_POST),
/* harmony export */   "cX": () => (/* binding */ FETCH_POST_DATA),
/* harmony export */   "rT": () => (/* binding */ FETCH_COMMENT_DATA),
/* harmony export */   "zJ": () => (/* binding */ FETCH_COMMENT_DETAILS)
/* harmony export */ });
const FETCH_POST_DATA = "FETCH_POST_DATA";
const FETCH_POST_DETAILS = "FETCH_POST_DETAILS";
const DELETE_POST = "DELETE_POST";
const FETCH_COMMENT_DATA = "FETCH_COMMENT_DATA";
const FETCH_COMMENT_DETAILS = "FETCH_COMMENT_DETAILS";


/***/ })

};
;